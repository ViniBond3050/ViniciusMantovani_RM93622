package br.com.fiap.viniciusmantovani_rm9622

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import br.com.fiap.viniciusmantovani_rm9622.model.Beach

class BeachAdapter(private val beachList: MutableList<Beach>, private val onDeleteClick: (Beach) -> Unit) :
    RecyclerView.Adapter<BeachAdapter.BeachViewHolder>() {

    class BeachViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvName: TextView = itemView.findViewById(R.id.tvName)
        val tvCity: TextView = itemView.findViewById(R.id.tvCity)
        val tvState: TextView = itemView.findViewById(R.id.tvState)
        val btnDelete: Button = itemView.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BeachViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.item_beach, parent, false)
        return BeachViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: BeachViewHolder, position: Int) {
        val currentBeach = beachList[position]
        holder.tvName.text = currentBeach.name
        holder.tvCity.text = currentBeach.city
        holder.tvState.text = currentBeach.state

        holder.btnDelete.setOnClickListener {
            onDeleteClick(currentBeach)
        }
    }

    override fun getItemCount() = beachList.size
}
