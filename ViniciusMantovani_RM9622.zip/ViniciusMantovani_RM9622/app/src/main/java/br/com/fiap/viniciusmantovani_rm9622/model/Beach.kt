package br.com.fiap.viniciusmantovani_rm9622.model

data class Beach(val name: String, val city: String, val state: String)
