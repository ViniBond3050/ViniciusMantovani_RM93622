import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import br.com.fiap.viniciusmantovani_rm9622.R

class InfoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_info)
    }
}
