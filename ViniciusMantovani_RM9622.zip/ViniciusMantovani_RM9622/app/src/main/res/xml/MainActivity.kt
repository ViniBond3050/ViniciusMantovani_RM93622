import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import br.com.fiap.viniciusmantovani_rm9622.BeachAdapter
import br.com.fiap.viniciusmantovani_rm9622.model.Beach
import br.com.fiap.viniciusmantovani_rm9622.R

class MainActivity : AppCompatActivity() {

    private val beachList = mutableListOf<Beach>()
    private lateinit var beachAdapter: BeachAdapter

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        beachAdapter = BeachAdapter(beachList) { beach ->
            deleteBeach(beach as Beach)
        }

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = beachAdapter

        val btnIncluir = findViewById<Button>(R.id.btnIncluir)
        btnIncluir.setOnClickListener {
            addBeach()
        }
    }

    private fun addBeach() {
        val etNome = findViewById<EditText>(R.id.etNome)
        val name = etNome.text.toString()
        val etCidade = findViewById<EditText>(R.id.etCidade)
        val city = etCidade.text.toString()
        val etEstado = findViewById<EditText>(R.id.etEstado)
        val state = etEstado.text.toString()

        if (name.isEmpty() || city.isEmpty() || state.isEmpty()) {
            Toast.makeText(this, "Todos os campos devem ser preenchidos", Toast.LENGTH_SHORT).show()
            return
        }

        if (name.length < 3 || city.length < 3 || state.length < 2) {
            Toast.makeText(this, "Verifique os tamanhos mínimos dos campos", Toast.LENGTH_SHORT).show()
            return
        }

        val beach = Beach(name, city, state)
        beachList.add(beach)
        beachAdapter.notifyItemInserted(beachList.size - 1)

        etNome.text.clear()
        etCidade.text.clear()
        etEstado.text.clear()
    }

    private fun deleteBeach(beach: Beach) {
        val position = beachList.indexOf(beach)
        if (position != -1) {
            beachList.removeAt(position)
            beachAdapter.notifyItemRemoved(position)
        }
    }
}
